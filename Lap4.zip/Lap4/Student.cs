namespace Lap4
{
    public class Student : Person
    {
        public string Program { set; get; }
        /*1. Business
         2. Computer
         3. Science*/
    }
}