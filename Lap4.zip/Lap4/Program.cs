﻿using System;

namespace Lap4
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            var faculty = new Faculty();
            var staff = new Staff();
        }
    }
}