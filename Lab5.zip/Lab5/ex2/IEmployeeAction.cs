namespace lab5.ex2
{
    public interface IEmployeeAction
    {
        double CalculateSalary();
    }
}