using System;

namespace Lab5.controller
{
    public class CustomerController
    {
        public void getName()
        {
            Console.WriteLine("vui long nhap ten cua ban; ");
            string name = Console.ReadLine();
        }
    }
}