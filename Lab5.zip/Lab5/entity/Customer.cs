using System;

namespace Lab5.entity
{
    public class Customer
    {
        public string Name { get; set; }
        
    }
}